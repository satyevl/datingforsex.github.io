DATABASE_SETTINGS = {'host': 'localhost',
                     'user': 'user',
                     'password': 'rehufu45',
                     'dbname': 'mysql.db'}
