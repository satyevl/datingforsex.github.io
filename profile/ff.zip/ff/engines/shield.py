from addons.containers import Containers
from models.container import Container, Container_Status
from api.tgapi import TgApiV2
import json
from api.tgweb import TelegramWeb
import re
import telebot
import asyncio
import string
import random
import time

class Shield:

    def __init__(self, container_id: int):
        self.container_id = container_id
        self.containers = Containers()
        self.container = Container()
        self.container.load(self.containers.get_container(id=self.container_id))

        self.temp = {}
        self.tgweb = None

        self.bot = telebot.TeleBot("2038833270:AAGJ_7iVSwSsB7I_Aw0uZtytAsb-DAgQKvo")

    def return_data(self, status=False, error='', error_msg='', data={}):
        return {'status': status,
                'data': data,
                'error': error,
                'error_msg': error_msg}

    def generate_alphanum_random_string(self, length):
        letters_and_digits = string.ascii_letters + string.digits
        rand_string = ''.join(random.sample(letters_and_digits, length))
        return rand_string

    def format_proxy(self, proxy):
        temp = proxy.split(':')
        proxy = {
            'proxy_type': 'socks5',  # (mandatory) protocol to use (see above)
            'addr': re.sub("^\s+|\n|\r|\s+$", '', temp[0]),  # (mandatory) proxy IP address
            'port': int(re.sub("^\s+|\n|\r|\s+$", '', temp[1])),  # (mandatory) proxy port number
            'username': temp[2],
            'password': temp[3],
            'rdns': True  # (optional) whether to use remote or local resolve, default remote
        }
        return proxy

    async def tg_auth_send_code(self):
        proxy_temp = self.container.settings.proxy.split(':')
        self.tgweb = TelegramWeb(self.container_id, proxy_temp[0], int(proxy_temp[1]), proxy_temp[2], proxy_temp[3])
        res = self.tgweb.open_browser()
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return
        res = self.tgweb.login_start(str(self.container.phone))
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return

        self.container.status = Container_Status.AUTH_CODE_SENDED
        self.containers.change_status_container(self.container_id, Container_Status.AUTH_CODE_SENDED)

    async def tg_auth_end(self):
        res = self.tgweb.login_end(str(self.container.settings.temp_code), str(self.container.settings.temp_password))
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return
        self.tgweb.close_browser()
        self.bot.send_message(self.container.user_id, '@{} - Успешная авторизация!'.format(self.container.channel))

        auth_data_file = open('sessions/{}.json'.format(self.container.phone), 'w')
        auth_data_file.write(json.dumps(res['data']['authdata']))
        auth_data_file.close()

        self.container.status = Container_Status.SLEEP
        self.containers.change_status_container(self.container_id, Container_Status.SLEEP)

    async def task_check(self):
        self.container.load(self.containers.get_container(id=self.container_id))

        if (self.container.status == Container_Status.AUTH_CODE_SEND):
            await self.tg_auth_send_code()
        if (self.container.status == Container_Status.AUTH_CODE_READY):
            await self.tg_auth_end()
        if (self.container.status == Container_Status.OPEN_CHANNEL):
            await self.open_channel()
        if (self.container.status == Container_Status.CLOSE_CHANNEL):
            await self.close_channel()
        if (self.container.status == Container_Status.REMOVE):
            print('Ну я всё - {}'.format(self.container_id))
            self.containers.remove_container(self.container_id)
            self.container.status = Container_Status.REMOVED
            self.containers.change_status_container(self.container_id, Container_Status.REMOVED)

    async def open_channel(self):
        res = self.tgweb.open_browser()
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return self.return_data(status=False)

        auth_data_file = open('sessions/{}.json'.format(self.container.phone), 'r')
        auth_data = json.loads(auth_data_file.read())
        auth_data_file.close()
        res = self.tgweb.login_by_authdata(auth_data)
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return self.return_data(status=False)
        res = self.tgweb.open_channel(str(self.container.settings.channel_id), self.container.settings.channel_link_now)
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return self.return_data(status=False)

        self.tgweb.close_browser()
        self.container.status = Container_Status.SLEEP
        self.containers.change_status_container(self.container_id, Container_Status.SLEEP)
        self.bot.send_message(self.container.user_id,
                              '@{} - Канал успешно открыт!'.format(self.container.channel))
        return self.return_data(status=True)

    async def close_channel(self):
        res = self.tgweb.open_browser()
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return self.return_data(status=False)

        auth_data_file = open('sessions/{}.json'.format(self.container.phone), 'r')
        auth_data = json.loads(auth_data_file.read())
        auth_data_file.close()
        res = self.tgweb.login_by_authdata(auth_data)
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return self.return_data(status=False)
        res = self.tgweb.close_channel(str(self.container.settings.channel_id))
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return self.return_data(status=False)

        self.tgweb.close_browser()
        self.container.status = Container_Status.SLEEP
        self.containers.change_status_container(self.container_id, Container_Status.SLEEP)
        self.bot.send_message(self.container.user_id,
                              '@{} - Канал успешно закрыт!'.format(self.container.channel))
        return self.return_data(status=True)

    async def get_channel_id(self):
        res = self.tgweb.open_browser()
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return self.return_data(status=False)

        auth_data_file = open('sessions/{}.json'.format(self.container.phone), 'r')
        auth_data = json.loads(auth_data_file.read())
        auth_data_file.close()
        res = self.tgweb.login_by_authdata(auth_data)
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return self.return_data(status=False)
        res = self.tgweb.get_channel_id(self.container.channel)
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return self.return_data(status=False)

        self.tgweb.close_browser()
        return self.return_data(status=True, data={'channel_id': res['data']['channel_id']})

    async def find_channel_by_id(self):
        res = self.tgweb.open_browser()
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return self.return_data(status=False)

        auth_data_file = open('sessions/{}.json'.format(self.container.phone), 'r')
        auth_data = json.loads(auth_data_file.read())
        auth_data_file.close()
        res = self.tgweb.login_by_authdata(auth_data)
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return self.return_data(status=False)
        res = self.tgweb.find_channel_by_id(str(self.container.settings.channel_id))
        if (res['status'] == False):
            self.bot.send_message(self.container.user_id, '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(self.container.channel))
            self.container.status = Container_Status.ERROR
            self.containers.change_status_container(self.container_id, Container_Status.ERROR)
            self.tgweb.close_browser()
            return self.return_data(status=False)

        self.tgweb.close_browser()
        return self.return_data(status=True, data={'channel_link': res['data']['channel_link']})

    async def change_link(self):
        if (self.container.settings.channel_id == 0):
            res = await self.get_channel_id()
            if (res['status'] == False):
                self.containers.change_status_container(self.container_id, Container_Status.ERROR)
                self.container.status = Container_Status.ERROR
                self.bot.send_message(self.container.user_id, '@{} - Ошибка получения данных о канале'.format(self.container.channel))
                return
            self.container.settings.channel_id = int(res['data']['channel_id'])
            self.containers.change_settings_container(self.container_id, self.container.settings)

        if (self.container.settings.channel_link_now == ''):
            self.container.settings.channel_link_now = self.container.channel
            self.containers.change_settings_container(self.container_id, self.container.settings)

        while True:
            while True:
                new = self.container.channel + self.generate_alphanum_random_string(1)
                if (new != self.container.settings.channel_link_now):
                    break

            res = self.tgweb.open_browser()
            if (res['status'] == False):
                self.bot.send_message(self.container.user_id,
                                      '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(
                                          self.container.channel))
                self.container.status = Container_Status.ERROR
                self.containers.change_status_container(self.container_id, Container_Status.ERROR)
                self.tgweb.close_browser()
                return

            auth_data_file = open('sessions/{}.json'.format(self.container.phone), 'r')
            auth_data = json.loads(auth_data_file.read())
            auth_data_file.close()
            res = self.tgweb.login_by_authdata(auth_data)
            if (res['status'] == False):
                self.bot.send_message(self.container.user_id,
                                      '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(
                                          self.container.channel))
                self.container.status = Container_Status.ERROR
                self.containers.change_status_container(self.container_id, Container_Status.ERROR)
                self.tgweb.close_browser()
                return self.return_data(status=False)

            res = self.tgweb.change_channel_link(str(self.container.settings.channel_id), new)
            if (res['status'] == False):
                self.tgweb.close_browser()
                if (res['error'] == 'channel_not_found'):
                    res = await self.find_channel_by_id()
                    if (res['status'] == False):
                        self.containers.change_status_container(self.container_id, Container_Status.ERROR)
                        self.container.status = Container_Status.ERROR
                        self.bot.send_message(self.container.user_id,
                                              '@{} - Канал не найден. Возможно снесли.'.format(
                                                  self.container.channel))
                        return
                    self.container.settings.channel_link_now = res['data']['channel_link']
                    self.containers.change_settings_container(self.container_id, self.container.settings)
                    self.container.channel = res['data']['channel_link']
                    self.containers.change_value_container(self.container_id, 'channel', self.container.channel)
                    continue
                if (res['error'] == 'flood'):
                    self.container.settings.change_time = int(time.time() + 60 * 60)
                    self.containers.change_settings_container(self.container_id, self.container.settings)
                    self.container.status = Container_Status.RELAX_TG_LIMITS
                    self.containers.change_status_container(self.container_id, Container_Status.RELAX_TG_LIMITS)
                    self.bot.send_message(self.container.user_id,
                                          '@{} - Поймал лимит на смену ссылки. Ухожу в отдых на 1 час.'.format(
                                              self.container.channel))
                    return
                if (res['error'] == 'link_exist'):
                    continue
                self.bot.send_message(self.container.user_id,
                                      '@{} - Возникла ошибка! Обратитесь к администратору бота.'.format(
                                          self.container.channel))
                self.container.status = Container_Status.ERROR
                self.containers.change_status_container(self.container_id, Container_Status.ERROR)
                self.tgweb.close_browser()
                return
            else:
                self.tgweb.close_browser()
                self.container.settings.channel_link_now = new
                self.containers.change_settings_container(self.container_id, self.container.settings)
                break

    async def run(self):
        while True:
            if (self.container.status != Container_Status.PREPARE and self.tgweb == None):
                proxy_temp = self.container.settings.proxy.split(':')
                self.tgweb = TelegramWeb(self.container_id, proxy_temp[0], int(proxy_temp[1]), proxy_temp[2],
                                         proxy_temp[3])

            await self.task_check()
            await asyncio.sleep(1)

            if (time.time() > self.container.settings.change_time and self.container.status == Container_Status.RELAX_TG_LIMITS):
                self.container.status = Container_Status.WORK
                self.containers.change_status_container(self.container_id, Container_Status.WORK)

            if (self.container.status == Container_Status.WORK and time.time() > self.container.settings.change_time):
                await self.change_link()
                self.container.settings.change_time = int(time.time() + self.container.settings.change_wait)
                self.containers.change_settings_container(self.container_id, self.container.settings)

            if (self.container.status == Container_Status.REMOVED):
                break

        print('Ну я всё - {}'.format(self.container_id))
