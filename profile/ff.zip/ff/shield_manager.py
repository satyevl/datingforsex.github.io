from engines.shield import Shield
import sys
import asyncio

params = sys.argv
container_id = params[1].split('=')[1]

shield = Shield(container_id)
asyncio.run(shield.run())