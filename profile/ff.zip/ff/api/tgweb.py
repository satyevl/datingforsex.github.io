import time
import traceback

import requests
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from seleniumwire import webdriver

from addons.logger import Logger


class LocalStorage:

    def __init__(self, driver):
        self.driver = driver

    def __len__(self):
        return self.driver.execute_script("return window.localStorage.length;")

    def items(self):
        return self.driver.execute_script( \
            "var ls = window.localStorage, items = {}; " \
            "for (var i = 0, k; i < ls.length; ++i) " \
            "  items[k = ls.key(i)] = ls.getItem(k); " \
            "return items; ")

    def keys(self):
        return self.driver.execute_script( \
            "var ls = window.localStorage, keys = []; " \
            "for (var i = 0; i < ls.length; ++i) " \
            "  keys[i] = ls.key(i); " \
            "return keys; ")

    def get(self, key):
        return self.driver.execute_script("return window.localStorage.getItem(arguments[0]);", key)

    def set(self, key, value):
        self.driver.execute_script("window.localStorage.setItem(arguments[0], arguments[1]);", key, value)

    def has(self, key):
        return key in self.keys()

    def remove(self, key):
        self.driver.execute_script("window.localStorage.removeItem(arguments[0]);", key)

    def clear(self):
        self.driver.execute_script("window.localStorage.clear();")

    def __getitem__(self, key):
        value = self.get(key)
        if value is None:
            raise KeyError(key)
        return value

    def __setitem__(self, key, value):
        self.set(key, value)

    def __contains__(self, key):
        return key in self.keys()

    def __iter__(self):
        return self.items().__iter__()

    def __repr__(self):
        return self.items().__str__()


class TelegramWeb():

    def __init__(self, container_id: int, proxy_host: str, proxy_port: int, proxy_username: str, proxy_password: str):
        self.logger = Logger(container_id)
        self.proxy = '{}:{}@{}:{}'.format(proxy_username, proxy_password, proxy_host, proxy_port)

        self.options = webdriver.FirefoxOptions()
        self.options.headless = True
        self.options.set_preference('intl.accept_languages', 'en-US, en')
        self.options.set_preference('dom.ipc.plugins.enabled.libflashplayer.so', False)
        self.options.set_preference("media.peerconnection.enabled", False)
        self.options_wire = {
            'proxy': {
                'http': 'http://{}:{}@{}:{}'.format(proxy_username, proxy_password, proxy_host, proxy_port),
                'https': 'http://{}:{}@{}:{}'.format(proxy_username, proxy_password, proxy_host, proxy_port),

            }
        }

    def return_data(self, status=False, error='', error_msg='', data={}):
        return {'status': status,
                'data': data,
                'error': error,
                'error_msg': error_msg}

    def check_proxy(self):
        for i in range(5):
            try:
                requests.get('https://www.google.ru/', timeout=2)
                return self.return_data(status=True)
            except:
                pass

        return self.return_data(status=False)

    def get_authdata(self):
        localstorage = LocalStorage(self.driver)
        return localstorage.items()

    def load_authdata(self, data):
        localstorage = LocalStorage(self.driver)

        for value in data:
            localstorage.set(value, data[value])

    def _open_browser(self):
        opened = False
        errors = []
        for i in range(2):
            try:
                self.driver = webdriver.Firefox(executable_path=r'geckodriver.exe', options=self.options,
                                                service_log_path='nul', seleniumwire_options=self.options_wire)
                self.driver.set_page_load_timeout(15)
                opened = True
                break
            except:
                opened = False
                errors.append(str(traceback.format_exc()))

        if (opened):
            return self.return_data(status=True)
        else:
            return self.return_data(status=False, error='open_browser/load_geckodriver', error_msg=str(errors))

    def close_browser(self):
        try:
            self.driver.close()
        except:
            pass

        try:
            self.driver.quit()
        except:
            pass

    def _login_start(self, phone: str):
        try:
            self.driver.get('https://web.telegram.org/k/')
        except:
            return self.return_data(status=False, error='login_start/get_login_page',
                                    error_msg=str(traceback.format_exc()))

        # Wait button loginbyphone
        finded = False
        for i in range(10):
            if ('Log in by phone Number' in self.driver.page_source):
                finded = True
                time.sleep(3)
                break
            time.sleep(1)

        if (finded == False):
            return self.return_data(status=False, error='login_start/wait_button_loginbyphone',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn = self.driver.find_element(By.XPATH, '/html/body/div[1]/div/div[2]/div[2]/div/div[2]/button[1]/div')
        except:
            return self.return_data(status=False, error='login_start/find_button_loginbyphone',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn.click()
        except:
            return self.return_data(status=False, error='login_start/click_button_loginbyphone',
                                    error_msg=str(traceback.format_exc()))

        # Wait phone input
        finded = False
        for i in range(10):
            if ('Phone Number' in self.driver.page_source):
                finded = True
                time.sleep(3)
                break
            time.sleep(1)

        if (finded == False):
            return self.return_data(status=False, error='login_start/wait_phone_input',
                                    error_msg=str(traceback.format_exc()))

        try:
            phone_input = self.driver.find_element(By.XPATH,
                                                   '/html/body/div[1]/div/div[2]/div[1]/div/div[3]/div[2]/div[1]')
        except:
            return self.return_data(status=False, error='login_start/find_phone_input',
                                    error_msg=str(traceback.format_exc()))

        try:
            phone_input.send_keys(Keys.BACKSPACE)
        except:
            return self.return_data(status=False, error='login_start/phone_input_send_backspace',
                                    error_msg=str(traceback.format_exc()))

        try:
            phone_input.send_keys(phone)
        except:
            return self.return_data(status=False, error='login_start/phone_input_send_phone',
                                    error_msg=str(traceback.format_exc()))

        # Wait button Next
        finded = False
        for i in range(10):
            if ('Next' in self.driver.page_source):
                finded = True
                time.sleep(3)
                break
            time.sleep(1)

        if (finded == False):
            return self.return_data(status=False, error='login_start/wait_button_next',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn = self.driver.find_element(By.XPATH, "(//div[@class='c-ripple'])[2]")
        except:
            return self.return_data(status=False, error='login_start/find_button_next',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn.click()
        except:
            return self.return_data(status=False, error='login_start/click_button_next',
                                    error_msg=str(traceback.format_exc()))

        # Wait text CodeSended
        finded = False
        for i in range(15):
            if ('We have sent you a message in Telegram' in self.driver.page_source):
                finded = True
                time.sleep(3)
                break
            time.sleep(1)

        if (finded == False):
            return self.return_data(status=False, error='login_start/wait_text_codesended',
                                    error_msg=str(traceback.format_exc()))

        return self.return_data(status=True, data={'authdata': self.get_authdata()})

    def _login_end(self, code: str, password=''):
        try:
            phone_input = self.driver.find_element(By.XPATH, "//input[@class='input-field-input']")
        except:
            return self.return_data(status=False, error='login_end/find_code_input',
                                    error_msg=str(traceback.format_exc()))

        try:
            phone_input.send_keys(code)
        except:
            return self.return_data(status=False, error='login_end/code_input_send_code',
                                    error_msg=str(traceback.format_exc()))

        # Wait text PasswordNeed or tag Search
        password_need = False
        finded = False
        for i in range(10):
            if ('Your account is protected with' in self.driver.page_source):
                password_need = True
                finded = True
                time.sleep(3)
                break
            if ('placeholder="Search"' in self.driver.page_source):
                finded = True
                time.sleep(3)
                break
            time.sleep(1)

        if (finded == False):
            return self.return_data(status=False, error='login_end/wait_passwordneed_or_search',
                                    error_msg=str(traceback.format_exc()))

        if (password_need):
            try:
                phone_input = self.driver.find_element(By.XPATH, "(//input[@class='input-field-input'])[2]")
            except:
                return self.return_data(status=False, error='login_end/find_password_input',
                                        error_msg=str(traceback.format_exc()))

            try:
                phone_input.send_keys(password)
            except:
                return self.return_data(status=False, error='login_end/password_input_send_password',
                                        error_msg=str(traceback.format_exc()))

            try:
                btn = self.driver.find_element(By.XPATH,
                                               "//button[contains(@class,'btn-primary btn-color-primary')]//div[1]")
            except:
                return self.return_data(status=False, error='login_end/find_button_next',
                                        error_msg=str(traceback.format_exc()))

            try:
                btn.click()
            except:
                return self.return_data(status=False, error='login_end/click_button_next',
                                        error_msg=str(traceback.format_exc()))

            # Wait tag Search
            finded = False
            for i in range(10):
                if ('placeholder="Search"' in self.driver.page_source):
                    finded = True
                    time.sleep(3)
                    break
                time.sleep(1)

            if (finded == False):
                return self.return_data(status=False, error='login_end/wait_search',
                                        error_msg=str(traceback.format_exc()))

        return self.return_data(status=True, data={'authdata': self.get_authdata()})

    def _login_by_authdata(self, authdata):
        try:
            self.driver.get('https://web.telegram.org/k/')
        except:
            return self.return_data(status=False, error='login_by_authdata/get_login_page',
                                    error_msg=str(traceback.format_exc()))

        try:
            self.load_authdata(authdata)
        except:
            return self.return_data(status=False, error='login_by_authdata/load_authdata',
                                    error_msg=str(traceback.format_exc()))

        try:
            self.driver.refresh()
        except:
            return self.return_data(status=False, error='login_by_authdata/refresh_login_page',
                                    error_msg=str(traceback.format_exc()))

        # Wait tag Search
        finded = False
        for i in range(10):
            if ('placeholder="Search"' in self.driver.page_source):
                finded = True
                time.sleep(3)
                break
            time.sleep(1)

        if (finded == False):
            return self.return_data(status=False, error='login_by_authdata/wait_search',
                                    error_msg=str(traceback.format_exc()))

        return self.return_data(status=True, data={'authdata': self.get_authdata()})

    def _find_channel_by_id(self, channel_id: str):
        try:
            self.driver.get('https://web.telegram.org/k/')
        except:
            return self.return_data(status=False, error='find_channel_by_id/get_login_page',
                                    error_msg=str(traceback.format_exc()))

        # Wait tag Search
        finded = False
        for i in range(10):
            if ('placeholder="Search"' in self.driver.page_source):
                finded = True
                time.sleep(3)
                break
            time.sleep(1)

        if (finded == False):
            return self.return_data(status=False, error='find_channel_by_id/wait_search',
                                    error_msg=str(traceback.format_exc()))

        try:
            chatlist = self.driver.find_element(By.XPATH, "(//ul[@class='chatlist'])")
        except:
            return self.return_data(status=False, error='find_channel_by_id/get_chatlist',
                                    error_msg=str(traceback.format_exc()))

        try:
            chats = chatlist.find_elements(By.TAG_NAME, 'li')
        except:
            return self.return_data(status=False, error='find_channel_by_id/get_chats',
                                    error_msg=str(traceback.format_exc()))

        try:
            for chat in chats:
                if (chat.get_attribute('data-peer-id') == channel_id):
                    chat.click()
                    break
        except:
            return self.return_data(status=False, error='find_channel_by_id/find_and_click_chat',
                                    error_msg=str(traceback.format_exc()))

        # Wait tag channel_top
        try:
            WebDriverWait(self.driver, 20).until(
                EC.visibility_of_element_located((By.XPATH, "//div[@class='top']//div[1]")))
        except:
            return self.return_data(status=False, error='find_channel_by_id/wait_channel_top',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn = self.driver.find_element(By.XPATH, "//div[@class='top']//div[1]")
        except:
            return self.return_data(status=False, error='find_channel_by_id/find_channel_top',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn.click()
        except:
            return self.return_data(status=False, error='find_channel_by_id/click_channel_top',
                                    error_msg=str(traceback.format_exc()))

        # Wait channel_block
        try:
            WebDriverWait(self.driver, 10).until(
                EC.visibility_of_element_located((By.XPATH, "//span[text()='Profile']")))
        except:
            return self.return_data(status=False, error='find_channel_by_id/wait_channel_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            channel_link_block = self.driver.find_element(By.XPATH,
                                                          "(//div[contains(@class,'row row-with-icon')]//div)[6]")
        except:
            return self.return_data(status=False, error='find_channel_by_id/extract_channel_link_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            channel_link = channel_link_block.text
        except:
            return self.return_data(status=False, error='find_channel_by_id/extract_channel_link',
                                    error_msg=str(traceback.format_exc()))

        if (channel_link == ''):
            return self.return_data(status=False, error='find_channel_by_id/link_empty',
                                    error_msg=str(traceback.format_exc()))

        return self.return_data(status=True, data={'channel_link': channel_link})

    def _get_channel_id(self, channel_link: str):
        if ('vatsapa_vaibera6' in channel_link):
            print(123)
        try:
            self.driver.get('https://web.telegram.org/k/')
        except:
            return self.return_data(status=False, error='get_channel_id/get_login_page',
                                    error_msg=str(traceback.format_exc()))

        # Wait tag Search
        finded = False
        for i in range(10):
            if ('placeholder="Search"' in self.driver.page_source):
                finded = True
                time.sleep(3)
                break
            time.sleep(1)

        if (finded == False):
            return self.return_data(status=False, error='get_channel_id/wait_search',
                                    error_msg=str(traceback.format_exc()))

        try:
            search_input = self.driver.find_element(By.XPATH, "//input[contains(@class,'input-field-input i18n')]")
        except:
            return self.return_data(status=False, error='get_channel_id/find_search_input',
                                    error_msg=str(traceback.format_exc()))

        try:
            search_input.send_keys('@' + channel_link)
        except:
            return self.return_data(status=False, error='get_channel_id/send_search_input_channel_link',
                                    error_msg=str(traceback.format_exc()))

        time.sleep(2)

        try:
            first_not_found = True
            try:
                chat = self.driver.find_element(By.XPATH, "(//div[@class='search-group search-group-contacts'])//ul//li")
            except Exception as e:
                if ('Unable to locate element' not in str(e)):
                    print('Unable to locate element' not in str(e))
                    raise Exception(str(e))
                first_not_found = False

            if (not first_not_found):
                chat = self.driver.find_element(By.XPATH,
                                                       "(//div[@class='search-group search-group-contacts is-short'])//ul//li")
        except:
            return self.return_data(status=False, error='get_channel_id/get_chat',
                                    error_msg=str(traceback.format_exc()))

        time.sleep(2)

        try:
            channel_id = chat.get_attribute('data-peer-id')
        except:
            return self.return_data(status=False, error='get_channel_id/extract_channel_id',
                                    error_msg=str(traceback.format_exc()))

        try:
            chat.click()
        except:
            return self.return_data(status=False, error='get_channel_id/click_chat',
                                    error_msg=str(traceback.format_exc()))

        try:
            WebDriverWait(self.driver, 20).until(
                EC.visibility_of_element_located((By.XPATH, "//div[@class='top']//div[1]")))
        except:
            return self.return_data(status=False, error='get_channel_id/wait_channel_top',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn = self.driver.find_element(By.XPATH, "//div[@class='top']//div[1]")
        except:
            return self.return_data(status=False, error='get_channel_id/find_channel_top',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn.click()
        except:
            return self.return_data(status=False, error='get_channel_id/click_channel_top',
                                    error_msg=str(traceback.format_exc()))

        # Wait channel_block
        try:
            WebDriverWait(self.driver, 10).until(
                EC.visibility_of_element_located((By.XPATH, "//span[text()='Profile']")))
        except:
            return self.return_data(status=False, error='get_channel_id/wait_channel_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            channel_link_block = self.driver.find_element(By.XPATH,
                                                          "(//div[contains(@class,'row row-with-icon')]//div)[6]")
        except:
            return self.return_data(status=False, error='get_channel_id/extract_channel_link_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            channel_link_temp = channel_link_block.text
        except:
            return self.return_data(status=False, error='get_channel_id/extract_channel_link',
                                    error_msg=str(traceback.format_exc()))

        if (channel_link_temp == ''):
            return self.return_data(status=False, error='get_channel_id/link_empty',
                                    error_msg=str(traceback.format_exc()))

        if (channel_link_temp != channel_link):
            return self.return_data(status=False, error='get_channel_id/channel_not_found',
                                    error_msg=str(traceback.format_exc()))

        return self.return_data(status=True, data={'channel_id': channel_id})

    def _change_channel_link(self, channel_id: str, new_channel_link: str):
        try:
            self.driver.get('https://web.telegram.org/k/')
        except:
            return self.return_data(status=False, error='change_channel_link/get_login_page',
                                    error_msg=str(traceback.format_exc()))

        # Wait tag Search
        finded = False
        for i in range(10):
            if ('placeholder="Search"' in self.driver.page_source):
                finded = True
                time.sleep(3)
                break
            time.sleep(1)

        if (finded == False):
            return self.return_data(status=False, error='change_channel_link/wait_search',
                                    error_msg=str(traceback.format_exc()))

        try:
            chatlist = self.driver.find_element(By.XPATH, "(//ul[@class='chatlist'])")
        except:
            return self.return_data(status=False, error='change_channel_link/get_chatlist',
                                    error_msg=str(traceback.format_exc()))

        try:
            chats = chatlist.find_elements(By.TAG_NAME, 'li')
        except:
            return self.return_data(status=False, error='change_channel_link/get_chats',
                                    error_msg=str(traceback.format_exc()))

        try:
            for chat in chats:
                if (chat.get_attribute('data-peer-id') == channel_id):
                    chat.click()
                    break
        except:
            return self.return_data(status=False, error='change_channel_link/find_and_click_chat',
                                    error_msg=str(traceback.format_exc()))

        # Wait tag channel_top
        try:
            WebDriverWait(self.driver, 20).until(
                EC.visibility_of_element_located((By.XPATH, "//div[@class='top']//div[1]")))
        except:
            return self.return_data(status=False, error='change_channel_link/wait_channel_top',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn = self.driver.find_element(By.XPATH, "//div[@class='top']//div[1]")
        except:
            return self.return_data(status=False, error='change_channel_link/find_channel_top',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn.click()
        except:
            return self.return_data(status=False, error='change_channel_link/click_channel_top',
                                    error_msg=str(traceback.format_exc()))

        try:
            edit_block = self.driver.find_element(By.XPATH, "//button[contains(@class,'btn-icon tgico-edit')]//div[1]")
        except:
            return self.return_data(status=False, error='change_channel_link/find_edit_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            edit_block.click()
        except:
            return self.return_data(status=False, error='change_channel_link/click_edit_block',
                                    error_msg=str(traceback.format_exc()))

        # Wait edit_block
        try:
            WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located((By.XPATH, "//span[text()='Edit']")))
        except:
            return self.return_data(status=False, error='change_channel_link/wait_edit_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            channel_type_block = self.driver.find_element(By.XPATH,
                                                          "(//div[contains(@class,'row row-with-icon')]//div)[10]")
        except:
            return self.return_data(status=False, error='change_channel_link/find_channel_type_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            channel_type_block.click()
        except:
            return self.return_data(status=False, error='change_channel_link/click_channel_type_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            link_input_block = self.driver.find_element(By.XPATH, "//input[contains(@name, 'group-public-link')]")
        except:
            return self.return_data(status=False, error='change_channel_link/find_link_input_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            link_input_block.clear()
        except:
            return self.return_data(status=False, error='change_channel_link/clear_link_input_block',
                                    error_msg=str(traceback.format_exc()))

        # Wait link_input empty
        try:
            WebDriverWait(self.driver, 20).until(
                EC.text_to_be_present_in_element_value((By.XPATH, "//input[contains(@name, 'group-public-link')]"), ''))
        except:
            return self.return_data(status=False, error='change_channel_link/wait_link_input_empty',
                                    error_msg=str(traceback.format_exc()))

        time.sleep(5)

        try:
            link_input_block.send_keys(new_channel_link)
        except:
            return self.return_data(status=False, error='change_channel_link/link_input_block_send_link',
                                    error_msg=str(traceback.format_exc()))

        finded_status = False
        try:
            for i in range(10):
                if ('invalid' in self.driver.find_element(By.XPATH,
                                                          "(//div[contains(@class,'sidebar-left-section-content')])//div[1]//div[1]//label").text or 'valid' in self.driver.find_element(
                    By.XPATH,
                    "(//div[contains(@class,'sidebar-left-section-content')])//div[1]//div[1]//label").text):
                    finded_status = True
                    break
                time.sleep(1)
        except:
            return self.return_data(status=False, error='change_channel_link/wait_status_link',
                                    error_msg=str(traceback.format_exc()))

        if (finded_status == False):
            return self.return_data(status=False, error='change_channel_link/wait_status_link',
                                    error_msg=str(traceback.format_exc()))

        time.sleep(5)
        try:
            if ('invalid' in self.driver.find_element(By.XPATH,
                                                      "(//div[contains(@class,'sidebar-left-section-content')])//div[1]//div[1]//label").text):
                return self.return_data(status=False, error='change_channel_link/link_exist',
                                        error_msg=str(traceback.format_exc()))
        except:
            return self.return_data(status=False, error='change_channel_link/check_link_status',
                                    error_msg=str(traceback.format_exc()))

        try:
            change_button = self.driver.find_element(By.XPATH,
                                                     "(//button[contains(@class,'btn-circle btn-corner')]//div)[5]")
        except:
            return self.return_data(status=False, error='change_channel_link/find_change_button',
                                    error_msg=str(traceback.format_exc()))

        try:
            change_button.click()
        except:
            return self.return_data(status=False, error='change_channel_link/click_change_button',
                                    error_msg=str(traceback.format_exc()))

        # Wait edit block
        try:
            WebDriverWait(self.driver, 5).until(EC.visibility_of_element_located((By.XPATH, "//span[text()='Edit']")))
        except:
            return self.return_data(status=False, error='change_channel_link/wait_edit_block_2',
                                    error_msg=str(traceback.format_exc()))

        self.driver.save_screenshot('screenie.png')

        return self.return_data(status=True)

    def _close_channel(self, channel_id: str):
        try:
            self.driver.get('https://web.telegram.org/k/')
        except:
            return self.return_data(status=False, error='close_channel/get_login_page', error_msg=str(traceback.format_exc()))

        # Wait tag Search
        finded = False
        for i in range(10):
            if ('placeholder="Search"' in self.driver.page_source):
                finded = True
                time.sleep(3)
                break
            time.sleep(1)

        if (finded == False):
            return self.return_data(status=False, error='close_channel/wait_search',
                                    error_msg=str(traceback.format_exc()))

        try:
            chatlist = self.driver.find_element(By.XPATH, "(//ul[@class='chatlist'])")
        except:
            return self.return_data(status=False, error='close_channel/get_chatlist',
                                    error_msg=str(traceback.format_exc()))

        try:
            chats = chatlist.find_elements(By.TAG_NAME, 'li')
        except:
            return self.return_data(status=False, error='close_channel/get_chats',
                                    error_msg=str(traceback.format_exc()))

        try:
            for chat in chats:
                if (chat.get_attribute('data-peer-id') == channel_id):
                    chat.click()
                    break
        except:
            return self.return_data(status=False, error='close_channel/find_and_click_chat',
                                    error_msg=str(traceback.format_exc()))

        # Wait tag channel_top
        try:
            WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located((By.XPATH, "//div[@class='top']//div[1]")))
        except:
            return self.return_data(status=False, error='close_channel/wait_channel_top',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn = self.driver.find_element(By.XPATH, "//div[@class='top']//div[1]")
        except:
            return self.return_data(status=False, error='close_channel/find_channel_top',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn.click()
        except:
            return self.return_data(status=False, error='close_channel/click_channel_top',
                                    error_msg=str(traceback.format_exc()))

        try:
            edit_block = self.driver.find_element(By.XPATH, "//button[contains(@class,'btn-icon tgico-edit')]//div[1]")
        except:
            return self.return_data(status=False, error='close_channel/find_edit_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            edit_block.click()
        except:
            return self.return_data(status=False, error='close_channel/click_edit_block',
                                    error_msg=str(traceback.format_exc()))

        # Wait edit_block
        try:
            WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located((By.XPATH, "//span[text()='Edit']")))
        except:
            return self.return_data(status=False, error='close_channel/wait_edit_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            channel_type_block = self.driver.find_element(By.XPATH,
                                                          "(//div[contains(@class,'row row-with-icon')]//div)[10]")
        except:
            return self.return_data(status=False, error='close_channel/find_channel_type_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            channel_type_block.click()
        except:
            return self.return_data(status=False, error='close_channel/click_channel_type_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            close_channel_button = self.driver.find_element(By.XPATH, "(//label[contains(@class,'row row-with-padding row-clickable hover-effect rp')])[1]")
        except:
            return self.return_data(status=False, error='close_channel/find_close_channel_button',
                                    error_msg=str(traceback.format_exc()))

        try:
            close_channel_button.click()
        except:
            return self.return_data(status=False, error='close_channel/click_close_channel_button',
                                    error_msg=str(traceback.format_exc()))

        time.sleep(5)

        try:
            change_button = self.driver.find_element(By.XPATH,
                                                     "(//button[contains(@class,'btn-circle btn-corner')]//div)[5]")
        except:
            return self.return_data(status=False, error='close_channel/find_change_button',
                                    error_msg=str(traceback.format_exc()))

        try:
            change_button.click()
        except:
            return self.return_data(status=False, error='close_channel/click_change_button',
                                    error_msg=str(traceback.format_exc()))

            # Wait edit block
        try:
            WebDriverWait(self.driver, 5).until(EC.visibility_of_element_located((By.XPATH, "//span[text()='Edit']")))
        except:
            return self.return_data(status=False, error='close_channel/wait_edit_block_2',
                                    error_msg=str(traceback.format_exc()))

        return self.return_data(status=True)

    def _open_channel(self, channel_id: str, new_channel_link: str):
        try:
            self.driver.get('https://web.telegram.org/k/')
        except:
            return self.return_data(status=False, error='open_channel/get_login_page', error_msg=str(traceback.format_exc()))

        # Wait tag Search
        finded = False
        for i in range(10):
            if ('placeholder="Search"' in self.driver.page_source):
                finded = True
                time.sleep(3)
                break
            time.sleep(1)

        if (finded == False):
            return self.return_data(status=False, error='open_channel/wait_search',
                                    error_msg=str(traceback.format_exc()))

        try:
            chatlist = self.driver.find_element(By.XPATH, "(//ul[@class='chatlist'])")
        except:
            return self.return_data(status=False, error='open_channel/get_chatlist',
                                    error_msg=str(traceback.format_exc()))

        try:
            chats = chatlist.find_elements(By.TAG_NAME, 'li')
        except:
            return self.return_data(status=False, error='open_channel/get_chats',
                                    error_msg=str(traceback.format_exc()))

        try:
            for chat in chats:
                if (chat.get_attribute('data-peer-id') == channel_id):
                    chat.click()
                    break
        except:
            return self.return_data(status=False, error='open_channel/find_and_click_chat',
                                    error_msg=str(traceback.format_exc()))

        # Wait tag channel_top
        try:
            WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located((By.XPATH, "//div[@class='top']//div[1]")))
        except:
            return self.return_data(status=False, error='open_channel/wait_channel_top',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn = self.driver.find_element(By.XPATH, "//div[@class='top']//div[1]")
        except:
            return self.return_data(status=False, error='open_channel/find_channel_top',
                                    error_msg=str(traceback.format_exc()))

        try:
            btn.click()
        except:
            return self.return_data(status=False, error='open_channel/click_channel_top',
                                    error_msg=str(traceback.format_exc()))

        try:
            edit_block = self.driver.find_element(By.XPATH, "//button[contains(@class,'btn-icon tgico-edit')]//div[1]")
        except:
            return self.return_data(status=False, error='open_channel/find_edit_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            edit_block.click()
        except:
            return self.return_data(status=False, error='open_channel/click_edit_block',
                                    error_msg=str(traceback.format_exc()))

        # Wait edit_block
        try:
            WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located((By.XPATH, "//span[text()='Edit']")))
        except:
            return self.return_data(status=False, error='open_channel/wait_edit_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            channel_type_block = self.driver.find_element(By.XPATH,
                                                          "(//div[contains(@class,'row row-with-icon')]//div)[10]")
        except:
            return self.return_data(status=False, error='open_channel/find_channel_type_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            channel_type_block.click()
        except:
            return self.return_data(status=False, error='open_channel/click_channel_type_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            close_channel_button = self.driver.find_element(By.XPATH, "(//label[contains(@class,'row row-with-padding row-clickable hover-effect rp')])[2]")
        except:
            return self.return_data(status=False, error='open_channel/find_close_channel_button',
                                    error_msg=str(traceback.format_exc()))

        try:
            close_channel_button.click()
        except:
            return self.return_data(status=False, error='open_channel/click_close_channel_button',
                                    error_msg=str(traceback.format_exc()))

        time.sleep(5)

        try:
            link_input_block = self.driver.find_element(By.XPATH, "//input[contains(@name, 'group-public-link')]")
        except:
            return self.return_data(status=False, error='open_channel/find_link_input_block',
                                    error_msg=str(traceback.format_exc()))

        try:
            link_input_block.send_keys(new_channel_link)
        except:
            return self.return_data(status=False, error='open_channel/link_input_block_send_link',
                                    error_msg=str(traceback.format_exc()))

        finded_status = False
        try:
            for i in range(10):
                if ('invalid' in self.driver.find_element(By.XPATH,
                                                          "(//div[contains(@class,'sidebar-left-section-content')])//div[1]//div[1]//label").text or 'valid' in self.driver.find_element(
                        By.XPATH,
                        "(//div[contains(@class,'sidebar-left-section-content')])//div[1]//div[1]//label").text):
                    finded_status = True
                    break
                time.sleep(1)
        except:
            return self.return_data(status=False, error='open_channel/wait_status_link',
                                    error_msg=str(traceback.format_exc()))

        if (finded_status == False):
            return self.return_data(status=False, error='open_channel/wait_status_link',
                                    error_msg=str(traceback.format_exc()))

        time.sleep(5)
        try:
            if ('invalid' in self.driver.find_element(By.XPATH,
                                                      "(//div[contains(@class,'sidebar-left-section-content')])//div[1]//div[1]//label").text):
                return self.return_data(status=False, error='open_channel/link_exist',
                                        error_msg=str(traceback.format_exc()))
        except:
            return self.return_data(status=False, error='open_channel/check_link_status',
                                    error_msg=str(traceback.format_exc()))

        try:
            change_button = self.driver.find_element(By.XPATH,
                                                     "(//button[contains(@class,'btn-circle btn-corner')]//div)[5]")
        except:
            return self.return_data(status=False, error='open_channel/find_change_button',
                                    error_msg=str(traceback.format_exc()))

        try:
            change_button.click()
        except:
            return self.return_data(status=False, error='open_channel/click_change_button',
                                    error_msg=str(traceback.format_exc()))

            # Wait edit block
        try:
            WebDriverWait(self.driver, 5).until(EC.visibility_of_element_located((By.XPATH, "//span[text()='Edit']")))
        except:
            return self.return_data(status=False, error='open_channel/wait_edit_block_2',
                                    error_msg=str(traceback.format_exc()))

        return self.return_data(status=True)

    def open_browser(self):
        for i in range(5):
            res = self._open_browser()
            if (res['status'] == True):
                return res
            if (res['status'] == False):
                pass
            self.logger.add_log({'error': res['error'],
                                 'error_msg': res['error_msg']})

        res = self.check_proxy()
        if (res['status'] == True):
            return self.return_data(status=False, error='unknown')
        if (res['status'] == False):
            self.logger.add_log({'error': 'proxy_error',
                                 'error_msg': ''})
            return self.return_data(status=False, error='proxy_error')

    def login_start(self, phone: str):
        for i in range(5):
            res = self._login_start(phone)
            if (res['status'] == True):
                return res
            if (res['status'] == False):
                pass
            self.logger.add_log({'error': res['error'],
                                 'error_msg': res['error_msg']})

        res = self.check_proxy()
        if (res['status'] == True):
            return self.return_data(status=False, error='unknown')
        if (res['status'] == False):
            self.logger.add_log({'error': 'proxy_error',
                                 'error_msg': ''})
            return self.return_data(status=False, error='proxy_error')

    def login_end(self, code: str, password=''):
        for i in range(5):
            res = self._login_end(code, password)
            if (res['status'] == True):
                return res
            if (res['status'] == False):
                pass
            self.logger.add_log({'error': res['error'],
                                 'error_msg': res['error_msg']})

        res = self.check_proxy()
        if (res['status'] == True):
            return self.return_data(status=False, error='unknown')
        if (res['status'] == False):
            self.logger.add_log({'error': 'proxy_error',
                                 'error_msg': ''})
            return self.return_data(status=False, error='proxy_error')

    def login_by_authdata(self, authdata):
        for i in range(5):
            res = self._login_by_authdata(authdata)
            if (res['status'] == True):
                return res
            if (res['status'] == False):
                pass
            self.logger.add_log({'error': res['error'],
                                 'error_msg': res['error_msg']})

        res = self.check_proxy()
        if (res['status'] == True):
            return self.return_data(status=False, error='unknown')
        if (res['status'] == False):
            self.logger.add_log({'error': 'proxy_error',
                                 'error_msg': ''})
            return self.return_data(status=False, error='proxy_error')

    def find_channel_by_id(self, channel_id: str):
        for i in range(5):
            res = self._find_channel_by_id(channel_id)
            if (res['status'] == True):
                return res
            if (res['status'] == False):
                pass
            self.logger.add_log({'error': res['error'],
                                 'error_msg': res['error_msg']})

        res = self.check_proxy()
        if (res['status'] == True):
            return self.return_data(status=False, error='unknown')
        if (res['status'] == False):
            self.logger.add_log({'error': 'proxy_error',
                                 'error_msg': ''})
            return self.return_data(status=False, error='proxy_error')

    def get_channel_id(self, channel_link: str):
        for i in range(5):
            res = self._get_channel_id(channel_link)
            if (res['status'] == True):
                return res
            if (res['status'] == False):
                pass
            self.logger.add_log({'error': res['error'],
                                 'error_msg': res['error_msg']})

        res = self.check_proxy()
        if (res['status'] == True):
            return self.return_data(status=False, error='unknown')
        if (res['status'] == False):
            self.logger.add_log({'error': 'proxy_error',
                                 'error_msg': ''})
            return self.return_data(status=False, error='proxy_error')

    def change_channel_link(self, channel_id: str, new_channel_link: str):
        for i in range(5):
            res = self._change_channel_link(channel_id, new_channel_link)
            if (res['status'] == True):
                return res
            if (res['status'] == False):
                if (res['error'] == 'change_channel_link/wait_channel_top'):
                    return self.return_data(status=False, error='channel_not_found')
                if (res['error'] == 'change_channel_link/wait_edit_block_2'):
                    return self.return_data(status=False, error='flood')
                if (res['error'] == 'change_channel_link/link_exist'):
                    return self.return_data(status=False, error='link_exist')
            self.logger.add_log({'error': res['error'],
                                 'error_msg': res['error_msg']})

        res = self.check_proxy()
        if (res['status'] == True):
            return self.return_data(status=False, error='unknown')
        if (res['status'] == False):
            self.logger.add_log({'error': 'proxy_error',
                                 'error_msg': ''})
            return self.return_data(status=False, error='proxy_error')

    def close_channel(self, channel_id: str):
        for i in range(5):
            res = self._close_channel(channel_id)
            if (res['status'] == True):
                return res
            if (res['status'] == False):
                pass
            self.logger.add_log({'error': res['error'],
                                 'error_msg': res['error_msg']})

        res = self.check_proxy()
        if (res['status'] == True):
            return self.return_data(status=False, error='unknown')
        if (res['status'] == False):
            self.logger.add_log({'error': 'proxy_error',
                                 'error_msg': ''})
            return self.return_data(status=False, error='proxy_error')

    def open_channel(self, channel_id: str, new_channel_link: str):
        for i in range(5):
            res = self._open_channel(channel_id, new_channel_link)
            if (res['status'] == True):
                return res
            if (res['status'] == False):
                pass
            self.logger.add_log({'error': res['error'],
                                 'error_msg': res['error_msg']})

        res = self.check_proxy()
        if (res['status'] == True):
            return self.return_data(status=False, error='unknown')
        if (res['status'] == False):
            self.logger.add_log({'error': 'proxy_error',
                                 'error_msg': ''})
            return self.return_data(status=False, error='proxy_error')
