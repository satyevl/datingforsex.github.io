from addons.db import DataBase
from settings import DATABASE_SETTINGS
from models.container import Container, Container_Status, Container_Settings

class Containers():

    def __init__(self):
        self.db = DataBase(DATABASE_SETTINGS)

    def add_container(self, container: Container):
        sql = "INSERT INTO containers (`status`, `user_id`, `channel`, `phone`, `settings`) " \
              "VALUES ('{}', '{}', '{}', '{}', '{}')" \
              "".format(container.status,
                        container.user_id,
                        container.channel,
                        container.phone,
                        container.settings)
        self.db.set(sql)

    def get_container(self, all: bool = False, id: int = 0):
        if (all):
            sql = "SELECT * FROM containers"
            res = self.db.getall(sql)
            return res

        sql = "SELECT * FROM containers WHERE id = {}".format(id)
        res = self.db.get(sql)
        return res

    def remove_container(self, id: int):
        sql = "DELETE FROM containers WHERE id = {}".format(id)
        self.db.set(sql)

    def change_status_container(self, id: int, status: Container_Status):
        sql = "UPDATE containers SET status = '{}' WHERE id = {}".format(status, id)
        self.db.set(sql)

    def change_value_container(self, id: int, key: str, value: str):
        sql = "UPDATE containers SET {} = '{}' WHERE id = {}".format(key, value, id)
        self.db.set(sql)

    def change_settings_container(self, id: int, settings: str):
        sql = "UPDATE containers SET settings = '{}' WHERE id = {}".format(settings, id)
        self.db.set(sql)
