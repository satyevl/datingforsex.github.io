import json


class Container_Settings:

    def __init__(self, change_wait: int = 0,
                 proxy: str = '',
                 temp_code: int = 0,
                 change_time: int = 0,
                 temp_password: str = '',
                 channel_id: int = 0,
                 channel_link_now: str = ''):
        self.change_wait = change_wait
        self.proxy = proxy
        self.temp_code = temp_code
        self.change_time = change_time
        self.temp_password = temp_password
        self.channel_id = channel_id
        self.channel_link_now = channel_link_now

    def load(self, data: json):
        self.change_wait = data['change_wait']
        self.proxy = data['proxy']
        self.temp_code = data['temp_code']
        self.change_time = data['change_time']
        self.temp_password = data['temp_password']
        self.channel_id = data['channel_id']
        self.channel_link_now = data['channel_link_now']

    def get_format(self):
        temp = {'change_wait': self.change_wait,
                'proxy': self.proxy,
                'temp_code': self.temp_code,
                'change_time': self.change_time,
                'temp_password': self.temp_password,
                'channel_id': self.channel_id,
                'channel_link_now': self.channel_link_now}
        return json.dumps(temp)

    def __str__(self):
        return self.get_format()


class Container_Status:
    PREPARE = 'prepare' # Подготовка
    AUTH_CODE_SEND = 'auth_code_send'  # Отправь код
    AUTH_CODE_SENDED = 'auth_code_sended'  # Код отправлен
    AUTH_CODE_READY = 'auth_code_ready'  # Прими код
    AUTH_CODE_GOOD = 'auth_code_ready'  # Авторизация успешна
    ERROR = 'error'
    WORK = 'work' # Работает
    RELAX_TG_LIMITS = 'relax_tg_limits' # Отдых в связи с лимитами Телеграмма
    SLEEP = 'sleep' # Остановлен
    REMOVE = 'remove' # Удаление
    REMOVED = 'removed'  # Удалён
    CLOSE_CHANNEL = 'close_channel'
    OPEN_CHANNEL = 'open_channel'
    NONE = 'none'


class Container:

    def __init__(self, status: Container_Status = Container_Status.NONE, user_id: int = 0, channel: str = '',
                 phone: int = 0, settings: Container_Settings = Container_Settings()):
        self.status = status
        self.user_id = user_id
        self.channel = channel
        self.phone = phone
        self.settings = settings

    def load(self, data: json):
        self.status = data['status']
        self.user_id = data['user_id']
        self.channel = data['channel']
        self.phone = data['phone']

        self.settings.load(json.loads(data['settings']))
