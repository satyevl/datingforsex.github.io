import telebot
from telebot.types import Message
from telebot import types
from addons.containers import Containers
from models.container import Container, Container_Status, Container_Settings

bot = telebot.TeleBot("5040424987:AAHXJWJ2CGyEO3o21NbGZcP4bPLcFZcYpY4")

class STEP:
    main = 'main'
    main_channels = 'main_channels'
    main_channels_add = 'main_channels_add'
    main_channels_add_two = 'main_channels_add_two'
    main_channels_show = 'main_channels_show'
    main_channels_edit_change_wait = 'main_channels_edit_change_wait'
    main_admins = 'main_admins'
    main_admins_add = 'main_admins_add'

class User():

    def __init__(self, id: int, step: str):
        self.id = id
        self.step = step
        self.last_msg = ''
        self.status_write = ''

class Users():

    def __init__(self):
        self.users = {}
        self.admins = [1204329503]
        self.access = [1204329503]

    def check(self, id: int):
        if (id not in self.access):
            return False
        if (id not in self.users):
            self.users[id] = User(id, 'main')
        return True

    def get(self, id: int):
        self.check(id)
        return self.users[id]

class Handler():

    def __init__(self, bot: telebot.TeleBot, users: Users):
        self.users = users
        self.bot = bot
        self.containers = Containers()

    def handle(self, user: User):
        self.read_msg(user)

        if (user.step == STEP.main):
            self.main(user)
            return
        if (user.step == STEP.main_admins):
            self.main_admins(user)
            return
        if (user.step == STEP.main_admins_add):
            self.main_admins_add(user)
            return
        if (user.step == STEP.main_channels):
            self.main_channels(user)
            return
        if (user.step == STEP.main_channels_add):
            self.main_channels_add(user)
            return
        if (STEP.main_channels_add_two in user.step):
            self.main_channels_add_two(user)
            return
        if (STEP.main_channels_show in user.step):
            self.main_channels_show(user)
            return
        if (STEP.main_channels_edit_change_wait in user.step):
            self.main_channels_edit_change_wait(user)
            return

    def read_msg(self, user: User):
        if (user.last_msg == 'Список каналов'):
            user.step = STEP.main_channels
            return
        if (user.last_msg == 'Добавить канал' and user.id):
            user.step = STEP.main_channels_add
            return
        if (user.last_msg == 'Список пользователей' and user.id in self.users.admins):
            user.step = STEP.main_admins
            return
        if (user.last_msg == 'Добавить пользователя' and user.id in self.users.admins):
            user.step = STEP.main_admins_add
            return

        if ('@' in user.last_msg and user.step == STEP.main_channels):
            channel = user.last_msg.replace('@', '')
            containers = self.containers.get_container(all=True)
            for value in containers:
                if (value['channel'] == channel):
                    user.step = STEP.main_channels_show + '_' + str(value['id'])
            return

        if (user.last_msg == 'Назад'):

            user.status_write = ''

            if (user.step == STEP.main_admins):
                user.step = STEP.main
                return
            if (user.step == STEP.main_admins_add):
                user.step = STEP.main_admins
                return
            if (user.step == STEP.main_channels):
                user.step = STEP.main
                return
            if (user.step == STEP.main_channels_add):
                user.step = STEP.main_channels
                return
            if (STEP.main_channels_show in user.step):
                user.step = STEP.main_channels
                return
            if (STEP.main_channels_edit_change_wait in user.step):
                container_id = int(user.step.replace(STEP.main_channels_edit_change_wait + '_', ''))
                user.step = STEP.main_channels_show + '_' + str(container_id)
                return
            if (STEP.main_channels_add_two in user.step):
                container_id = int(user.step.replace(STEP.main_channels_add_two + '_', ''))
                self.containers.change_status_container(container_id, Container_Status.REMOVE)
                user.step = STEP.main_channels
                return
        
    def main(self, user: User):
        resp_msg = 'Главное меню'

        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1, one_time_keyboard=True)
        itembtn1 = types.KeyboardButton('Список каналов')
        markup.add(itembtn1)
        if (user.id in self.users.admins):
            itembtn1 = types.KeyboardButton('Список пользователей')
            markup.add(itembtn1)

        bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())

    def main_channels(self, user):
        resp_msg = 'Каналы'

        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1, one_time_keyboard=True)
        itembtn1 = types.KeyboardButton('Добавить канал')
        markup.add(itembtn1)

        containers = self.containers.get_container(all=True)
        for value in containers:
            if (value['user_id'] == user.id):
                itembtn1 = types.KeyboardButton('@' + value['channel'])
                markup.add(itembtn1)

        itembtn1 = types.KeyboardButton('Назад')
        markup.add(itembtn1)

        bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())

    def main_channels_add(self, user):
        resp_msg = 'Введите номер Telegram аккаунта'

        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1, one_time_keyboard=False)
        itembtn1 = types.KeyboardButton('Назад')
        markup.add(itembtn1)

        if (user.last_msg != 'Добавить канал'):
            tg_phone = 0
            is_int = False
            try:
                tg_phone = int(user.last_msg)
                is_int = True
            except:
                pass

            if (is_int):
                containers = self.containers.get_container(all=True)
                for value in containers:
                    if (value['phone'] == tg_phone):
                        resp_msg = 'Данный номер телефона уже присутсвует в системе!\nВведите другой номер.'
                        bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())
                        return

                self.containers.add_container(Container(status=Container_Status.PREPARE,
                                                        user_id=user.id,
                                                        phone=tg_phone,
                                                        settings=Container_Settings()))
                container_id = 0
                containers_temp = self.containers.get_container(all=True)
                for value in containers_temp:
                    if (value['phone'] == tg_phone):
                        container_id = value['id']
                        break

                user.step = STEP.main_channels_add_two + '_' + str(container_id)
                self.main_channels_add_two(user)
                return
            else:
                resp_msg = 'Вы ввели не число.'

        bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())

    def main_channels_add_two(self, user):
        container_id = int(user.step.replace(STEP.main_channels_add_two + '_', ''))
        container = Container()
        container.load(self.containers.get_container(id=container_id))

        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1, one_time_keyboard=False)
        itembtn1 = types.KeyboardButton('Назад')
        markup.add(itembtn1)

        if (container.settings.proxy == ''):
            if (user.status_write == 'wait'):
                if (len(user.last_msg.split(':')) != 4):
                    resp_msg = 'Неверный формат прокси.'
                    bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())
                    return
                container.settings.proxy = user.last_msg
                self.containers.change_settings_container(container_id, container.settings)
                user.status_write = ''
            else:
                resp_msg = 'Введите прокси HTTP формате:\nip:port:username:password'
                bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())
                user.status_write = 'wait'
                return

        if (container.channel == ''):
            if (user.status_write == 'wait'):
                if ('@' not in user.last_msg):
                    resp_msg = 'Неверный формат ссылки.'
                    bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())
                    return
                self.containers.change_value_container(container_id, 'channel', user.last_msg[1:])
                user.status_write = ''
            else:
                resp_msg = 'Введите ссылку на канал в формате:\n@channel'
                bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())
                user.status_write = 'wait'
                return

        if (container.settings.temp_password == ''):
            if (user.status_write == 'wait'):
                container.settings.temp_password = user.last_msg
                self.containers.change_settings_container(container_id, container.settings)
                user.status_write = ''
            else:
                resp_msg = 'Введите пароль от аккаунта.\nЕсли он не уставновлен, напишите всё что угодно.'
                bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())
                user.status_write = 'wait'
                return

        if (container.settings.temp_code == 0):
            if (user.status_write == 'wait'):
                is_int = False
                try:
                    int(user.last_msg)
                    is_int = True
                except:
                    pass
                if (is_int == False):
                    resp_msg = 'Вы ввели не число.'
                    bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())
                    return
                container.settings.temp_code = user.last_msg
                self.containers.change_settings_container(container_id, container.settings)
                user.status_write = ''
                self.containers.change_status_container(container_id, Container_Status.AUTH_CODE_READY)

                user.step = STEP.main_channels
                self.main_channels(user)
                return
            else:
                resp_msg = 'Введите пришедший код.'
                bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())
                user.status_write = 'wait'
                self.containers.change_status_container(container_id, Container_Status.AUTH_CODE_SEND)
                return


    def main_admins(self, user):
        resp_msg = 'Пользователи\n\n'

        for i in range(len(self.users.access)):
            resp_msg += '{}. {}\n'.format(i, self.users.access[i])

        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1, one_time_keyboard=True)
        itembtn1 = types.KeyboardButton('Добавить пользователя')
        markup.add(itembtn1)
        itembtn1 = types.KeyboardButton('Назад')
        markup.add(itembtn1)

        bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())

    def main_admins_add(self, user):
        resp_msg = 'Введите ID пользователя Telegram\nЕго можно получить при помощи бота @myidbot'

        if (user.last_msg != 'Добавить пользователя'):
            user_id = 0
            is_int = False
            try:
                user_id = int(user.last_msg)
                is_int = True
            except:
                pass

            if (is_int):
                self.users.access.append(user_id)
                resp_msg = 'Пользователь успешно добавлен!'
                bot.send_message(user.id, resp_msg)
                user.step = STEP.main_admins
                self.main_admins(user)
                return
            else:
                resp_msg = 'Вы ввели не число.'

        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1, one_time_keyboard=True)
        itembtn1 = types.KeyboardButton('Назад')
        markup.add(itembtn1)

        bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())

    def reformat_status(self, status):
        if (status == Container_Status.SLEEP):
            return 'Остановлен'
        if (status == Container_Status.WORK):
            return 'Работает'
        if (status == Container_Status.RELAX_TG_LIMITS):
            return 'Отдых (из-за лимитов)'
        if (status == Container_Status.ERROR):
            return 'Ошибка'
        return status

    def main_channels_show(self, user):
        container_id = int(user.step.replace(STEP.main_channels_show + '_', ''))
        container = Container()
        container.load(self.containers.get_container(id=container_id))

        if (user.last_msg == 'Запустить'):
            container.status = Container_Status.WORK
            self.containers.change_status_container(container_id, Container_Status.WORK)
        if (user.last_msg == 'Остановить'):
            container.status = Container_Status.SLEEP
            self.containers.change_status_container(container_id, Container_Status.SLEEP)
        if (user.last_msg == 'Открыть канал'):
            container.status = Container_Status.OPEN_CHANNEL
            self.containers.change_status_container(container_id, Container_Status.OPEN_CHANNEL)
        if (user.last_msg == 'Закрыть канал'):
            container.status = Container_Status.CLOSE_CHANNEL
            self.containers.change_status_container(container_id, Container_Status.CLOSE_CHANNEL)
        if (user.last_msg == 'Удалить канал'):
            container.status = Container_Status.REMOVE
            self.containers.change_status_container(container_id, Container_Status.REMOVE)
            user.step = STEP.main_channels
            self.main_channels(user)
            return

        if (user.last_msg == 'Изменить интервал'):
            user.step = STEP.main_channels_edit_change_wait + '_' + str(container_id)
            self.main_channels_edit_change_wait(user)
            return

        resp_msg = 'Канал - {}\n' \
                   'Текущая ссылка - {}\n' \
                   'Статус - {}\n' \
                   'Интервал - {} сек.\n' \
                   'Номер - {}\n' \
                   ''.format('@' + container.channel,
                             '@' + container.settings.channel_link_now,
                             self.reformat_status(container.status),
                             container.settings.change_wait,
                             container.phone)

        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1, one_time_keyboard=True)
        if (container.status != Container_Status.WORK):
            itembtn1 = types.KeyboardButton('Запустить')
            markup.add(itembtn1)
        else:
            itembtn1 = types.KeyboardButton('Остановить')
            markup.add(itembtn1)
        itembtn1 = types.KeyboardButton('Открыть канал')
        markup.add(itembtn1)
        itembtn1 = types.KeyboardButton('Закрыть канал')
        markup.add(itembtn1)
        itembtn1 = types.KeyboardButton('Изменить интервал')
        markup.add(itembtn1)
        itembtn1 = types.KeyboardButton('Удалить канал')
        markup.add(itembtn1)
        itembtn1 = types.KeyboardButton('Назад')
        markup.add(itembtn1)


        bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())

    def main_channels_edit_change_wait(self, user):
        container_id = int(user.step.replace(STEP.main_channels_edit_change_wait + '_', ''))
        container = Container()
        container.load(self.containers.get_container(id=container_id))

        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1, one_time_keyboard=True)
        itembtn1 = types.KeyboardButton('Назад')
        markup.add(itembtn1)

        if (user.status_write == 'wait'):
            change_wait = 0
            is_int = False
            try:
                change_wait = int(user.last_msg)
                is_int = True
            except:
                pass

            if (is_int):
                container.settings.change_wait = change_wait
                self.containers.change_settings_container(container_id, container.settings)
                resp_msg = 'Интервал успешно изменён!'
                bot.send_message(user.id, resp_msg)
                user.step = STEP.main_channels_show + '_' + str(container_id)
                user.status_write = ''
                self.main_channels_show(user)
                return
            else:
                resp_msg = 'Вы ввели не число.'
                bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())
        else:
            resp_msg = 'Введите новый интервал смены ссылки(секунды).'
            bot.send_message(user.id, resp_msg, reply_markup=markup.to_json())
            user.status_write = 'wait'
            return


users = Users()
handler = Handler(bot, users)

@bot.message_handler(commands=['start', 'help'])
def commands(message: Message):
    if (not users.check(message.from_user.id)):
        return

    user = users.get(message.from_user.id)
    user.last_msg = message.text

    handler.handle(user)


@bot.message_handler(func=lambda message: True)
def talk(message: Message):
    if (not users.check(message.from_user.id)):
        return

    user = users.get(message.from_user.id)
    user.last_msg = message.text

    handler.handle(user)


bot.infinity_polling()
