from addons.db import DataBase
from settings import DATABASE_SETTINGS
import json

class Logger:

    def __init__(self, container_id: int):
        self.db = DataBase(DATABASE_SETTINGS)
        self.container_id = container_id

    def add_log(self, msg: json):
        self.db.set("INSERT INTO logs (`container_id`, `msg`) VALUES ('{}', '{}')"
                    "".format(self.container_id, json.dumps(msg).replace("'", "\\'")))
