import time
import pymysql


class DataBase():

    def __init__(self, auth_data):
        self.host = auth_data['host']
        self.user = auth_data['user']
        self.password = auth_data['password']
        self.dbname = auth_data['dbname']
        # self.threadname = threadname

    def reconnect(self, redirect=None, param=None):
        try:
            # AddLog("Р РµРєРѕРЅРµРєС‚ " + self.threadname, None, False)
            connect = pymysql.connect(host=self.host,
                                           user=self.user,
                                           password=self.password,
                                           db=self.dbname,
                                           charset='utf8mb4',
                                           cursorclass=pymysql.cursors.DictCursor)
            # AddLog("РџРѕРґРєР»СЋС‡РµРЅС‹ Рє Р‘Р” " + self.threadname, None, False)
            if (redirect != None):
                if (redirect == "Get"):
                    return self.get(param)
                if (redirect == "GetAll"):
                    return self.getall(param)
                if (redirect == "Set"):
                    self.set(param)

            return connect
        except:
            # AddLog("Р‘Р” РЅРµ РґРѕСЃС‚СѓРїРЅР°", None, False)
            time.sleep(10)
            return False

    def con_db(self):
        while True:
            res = self.reconnect()
            if (res != False):
                return res

    def get(self, sql):
        connect = self.con_db()
        while True:
            try:
                cursor = connect.cursor()
                cursor.execute(sql)
                row = cursor.fetchone()
                cursor.close()
                connect.close()
                return row
            except Exception as exept:
                print(exept)
                # AddLog(str(exept) + " Р—Р°РїСЂРѕСЃ: '" + sql + "'", None, False)
                connect = self.con_db()
                continue

    def getall(self, sql):
        connect = self.con_db()
        while True:
            try:
                cursor = connect.cursor()
                cursor.execute(sql)
                row = cursor.fetchall()
                cursor.close()
                connect.close()
                return row
            except Exception as exept:
                # AddLog(str(exept) + " Р—Р°РїСЂРѕСЃ: '" + sql + "'", None, False)
                connect = self.con_db()
                continue

    def set(self, sql):
        connect = self.con_db()
        while True:
            try:
                cursor = connect.cursor()
                cursor.execute(sql)
                connect.commit()
                cursor.close()
                connect.close()
                return
            except Exception as exept:
                # AddLog(str(exept) + " Р—Р°РїСЂРѕСЃ: '" + sql + "'", None, False)
                connect = self.con_db()
                continue