DATABASE_SETTINGS = {'host': '',
                     'user': '',
                     'password': '',
                     'dbname': ''}
