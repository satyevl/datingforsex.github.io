from addons.containers import Containers
import time
import subprocess

class Node:

    def __init__(self):
        self.containers = Containers()
        self.containers_started = []

    def start_shield(self, container_id: int):
        self.containers_started.append(container_id)
        subprocess.Popen('python shield_manager.py id={}'.format(container_id), shell=True)

    def engine(self):
        while True:
            containers_list = self.containers.get_container(all=True)
            for container in containers_list:
                if (container['id'] not in self.containers_started):
                    self.start_shield(container['id'])

            time.sleep(1)
