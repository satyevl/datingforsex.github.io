import datetime
from telethon import TelegramClient, types, functions
import random
import json


class TgApiV2():

    def __init__(self):
        self.device_info = {}
        self.session = ''

    def return_data(self, status=False, error_msg='', data={}):
        return {'status': status,
                'data': data,
                'error_msg': error_msg}

    def gen_device(self, session):
        system_version_list = ['Android R (30)', 'Android Q (29)', 'Android P (28)', 'Android O (27)', 'Android O (26)',
                          'Android SDK 25', 'Android SDK 24', 'Android SDK 23']
        device_model_list = ['Redmi 4X', 'PRA-TL10', 'Galaxy Nexus', 'SM-J111F', 'Moto G', 'SM-A125F', 'Mi 9T', 'HRY-LX1',
                        'Nokia 2', 'en-us', 'SAMSUNG SM-G950F', 'FLA-LX1', 'Redmi Note 7', 'SM-A505FN', 'SM-A705FN',
                        'Pixel 2 XL', 'SM-G892A', 'Redmi Note 8 Pro', 'Mi Note 10 Pro', 'ZTE Blade A3 2019RU',
                        'SM-N900K', 'Redmi Note 4', 'Redmi Note 5', 'Moto E', 'SM-G975F', 'FIG-LX1', 'SAMSUNG SM-G955F',
                        'Redmi 7', 'SAMSUNG SM-J510FN', 'SM-G950F', 'SAMSUNG SM-G532F', 'Redmi 7A', 'SM-T385', 'GM1910',
                        'MI 8 Lite', 'ART-L29N', 'SAMSUNG SM-A505FM', 'SAMSUNG SM-A505FN', 'SM-A102U', 'Mi MIX 2',
                        'SM-T590', 'MI 9', 'Redmi 4A', 'CPH1909', 'CMR-AL09', 'SAMSUNG SM-A750FN', 'ANE-LX1', 'SM-T561',
                        'SAMSUNG SM-T355', 'STK-LX1', 'CPH1931', 'MAR-LX1M', 'SM-A307FN', 'SM-G960F', 'TA-1041',
                        'Mi A2', 'MI 8 SE', 'Redmi Note 3', 'LLD-L31', 'Redmi Note 8T', 'POCOPHONE F1',
                        'SAMSUNG SM-A310F', 'PMT3157_3G', 'SAMSUNG SM-A530F', 'Redmi 5', 'JAT-LX1', 'M2004J19C',
                        'Redmi Note 6 Pro', 'SAMSUNG SM-J120F', 'SM-T585', 'SM-A105F', 'Redmi 5A', 'MRD-LX1F',
                        'Redmi Note 9S', 'Redmi 5 Plus', 'Redmi Note 9 Pro', 'SM-G930V', 'YAL-L21', 'SM-T515',
                        'M2003J15SC', 'Le 2', 'Mi A2 Lite', 'SM-J120F', 'VOG-L29', 'SM-A415F', 'SM-G955F',
                        'SAMSUNG SM-A520F', 'RMX1931', 'Redmi Note 8', 'M5c', 'vivo 1901', 'SM-A600FN', 'COR-L29',
                        'SM-N910C', 'COL-L29', 'M5s', 'HUAWEI CUN-U29', 'SM-A920F', 'IN2023', 'TA-1053',
                        'Lenovo TB2-X30L', 'SM-G532F', 'SM-A515F', 'JSN-L21', 'SNE-LX1', 'Redmi 6A', 'SM-G970F',
                        'AUM-L41', 'Redmi 4', 'HD1900', 'SAMSUNG SM-G935F', 'T1-701u', 'SM-A500F', 'SAMSUNG SM-G930F',
                        'Mi A3', 'M6 Note', 'SM-A520F', 'SM-G965F', 'HRY-LX1T', 'SAMSUNG SM-T580', 'SAMSUNG SM-M315F',
                        'BAH-L09', 'M2102J20SG', 'AUM-L29', 'MI 8', 'Redmi 6', 'SM-G930F', 'Meizu M6s',
                        'SAMSUNG SM-A715F', 'SM-T355', 'SM-T595', 'ELE-L29', 'SAMSUNG SM-G985F', 'SAMSUNG SM-A515F',
                        'SM-J510H', 'LM-Q710', 'Lenovo TB-8703X', 'Redmi Go', 'GM1900', 'LG-K220', 'MI PLAY', 'Nexus 4',
                        'SAMSUNG SM-A105F', 'M2007J20CG', 'LGLS775', 'arm_64', 'SM-G988B', 'Plane 1596 3G PS1213PG',
                        'SM-T830', 'ZE620KL', 'POCO F2 Pro', 'Redmi Note 2', 'SM-G975U', 'Nokia 2.2', 'MI PAD',
                        'Nokia 3.1', 'SM-A315F', 'SM-G9750', 'SM-A300F', 'POT-LX1', 'P023', 'Lenovo A7600-H', 'KSA-LX9',
                        'SM-G973F', 'Pixel', 'Redmi 3S', 'STF-L09', 'SM-A217F', 'SM-J260F', 'AGS2-L09', 'SM-T555',
                        'Redmi Note 5A Prime', 'RMX3241', 'Mi Note 10 Lite', 'Mi 9 Lite', 'SM-J530FM', 'moto e5 play',
                        'SAMSUNG SM-N985F', 'dandelion', 'LEX722', 'SAMSUNG SM-A510F', 'HTC Desire 526G dual sim',
                        'CPN-L09', 'SM-G900V', 'vivo 1724', 'MI PAD 4 PLUS', 'AGS-L09', 'SAMSUNG SM-T819', 'DLI-TL20',
                        'SM-A205U', 'Redmi Note 5A', 'SM-A320FL', 'ONEPLUS A6010', 'MI 5', 'RMX1971', 'MI MAX 3',
                        'SAMSUNG SM-G975F', 'ONEPLUS A6013', 'SM-T311', 'SAMSUNG SM-N960F', 'SM-A505FM', 'SM-G985F',
                        'LND-L29', 'INE-LX1', 'vivo 1915', 'ZB602KL', 'YAL-L41', 'SM-J510FN', 'ONEPLUS A5000',
                        'Redmi 8', 'DUA-L22', 'MRX-AL09', 'Mi Note 10', 'SAMSUNG SM-G965F', 'SAMSUNG SM-A600FN',
                        'SM-A530F', 'SAMSUNG SM-J320F', 'ZTE A7020', 'P01T_1', 'M2002J9E', 'A5_Pro', 'Microsoft',
                        'SKR-H0', 'SM-J710F', 'SAMSUNG SM-A405FM', 'Galaxy Nexus', 'MAR-LX1H', 'RNE-L21', 'Redmi 8A',
                        'SM-T819', 'HLK-AL00', 'SM-G998B', 'FDR-A01L', 'SM-G7102', 'Mi 9T Pro', 'Z00D', 'Pixel 2',
                        'vivo 1804', 'CMR-W09', 'FS506', 'Mi A1', 'SM-G935F', 'LLD-L21', 'Mi 9 SE', 'Pixel 3 XL',
                        'ZC520KL']
        app_version_list = ['8.2.7 (2470)']
        app_list = [{'app_id': 6, 'app_hash': 'eb06d4abfb49dc3eeb1aeb98ae0f581e'}]

        template = {"session_file": "", "phone": "", "app_id": 0, "app_hash": "", "sdk": "", "device": "",
                    "app_version": "", "lang_pack": "", "system_lang_pack": "", "register_time": 0, "first_name": "",
                    "last_name": "", "proxy": None, "last_check_time": 0, "success_registred": False, "ipv6": False,
                    "avatar": None}

        app_info = random.choice(app_list)
        sdk = random.choice(system_version_list)
        device_model = random.choice(device_model_list)
        app_version = random.choice(app_version_list)
        template['app_id'] = app_info['app_id']
        template['app_hash'] = app_info['app_hash']
        template['sdk'] = sdk
        template['device'] = device_model
        template['app_version'] = app_version

        self.device_info['sdk'] = sdk
        self.device_info['device'] = device_model
        self.device_info['app_version'] = app_version
        self.device_info['app_id'] = app_info['app_id']
        self.device_info['app_hash'] = app_info['app_hash']

        file_res = open(session.replace('.session', '') + '.json', 'w', encoding='utf-8')
        json.dump(template, file_res)
        file_res.close()

    def set_device(self, session: str, api_id=6, api_hash='eb06d4abfb49dc3eeb1aeb98ae0f581e',
                   device_model='', system_version='', app_version='', proxy=None):

        self.session = session

        if (device_model == '' or system_version == '' or app_version == ''):
            try:
                with open('{}.json'.format(session)) as data:
                    self.device_info = json.loads(data.read())
            except:
                self.gen_device(session)
        else:
            self.device_info['sdk'] = system_version
            self.device_info['device'] = device_model
            self.device_info['app_version'] = app_version
            self.device_info['app_id'] = api_id
            self.device_info['app_hash'] = api_hash

        self.client = TelegramClient(session=session, api_id=self.device_info['app_id'],
                                     api_hash=self.device_info['app_hash'],
                                     device_model=self.device_info['device'],
                                     system_version=self.device_info['sdk'],
                                     app_version=self.device_info['app_version'], system_lang_code='ru',
                                     lang_code='ru', timeout=2, auto_reconnect=False, connection_retries=0,
                                     flood_sleep_threshold=0, proxy=proxy)

    async def auth_session(self):
        try:
            await self.client.connect()
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        try:
            res = await self.client.get_me()
            if (res == None):
                raise Exception
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True)

    async def send_code(self, phone):
        try:
            await self.client.connect()
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        try:
            res = await self.client.send_code_request(str(phone))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'phone_code_hash': res.phone_code_hash})

    async def sign_in_password(self, password):
        try:
            await self.client.sign_in(password=password)
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True)

    async def sign_in(self, phone, phone_code_hash, code, password=''):
        try:
            await self.client.sign_in(phone=str(phone), phone_code_hash=phone_code_hash, code=code)
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            if ('Two-steps verification is enabled and a password is required' in str(e)):
                return await self.sign_in_password(password)
            else:
                return self.return_data(status=False, error_msg=str(e))

        try:
            await self.client.get_me()
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        with open('{}.json'.format(self.session), 'w') as file:
            file.write(json.dumps(self.device_info))

        return self.return_data(status=True)

    async def sign_up(self, phone, phone_code_hash, code, first_name, last_name=''):
        try:
            await self.client.sign_up(phone=str(phone), phone_code_hash=phone_code_hash, first_name=first_name,
                                last_name=last_name, code=code)
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True)

    async def set_password(self, password):
        try:
            await self.client.edit_2fa(new_password=password)
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True)

    async def set_username(self, username):
        try:
            res = await self.client(functions.account.UpdateUsernameRequest(
                username=username
            ))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'set': res})

    async def disconnect(self):
        try:
            await self.client.disconnect()
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True)

    async def report_user_spam(self, userid):
        try:
            res = await self.client(functions.account.ReportPeerRequest(
                peer=userid,
                reason=types.InputReportReasonSpam(), message=''))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'report': res})

    async def block_user(self, userid):
        try:
            res = await self.client(functions.contacts.BlockRequest(
                id=userid
            ))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'block': res})

    async def clear_chat_user(self, userid):
        try:
            res = await self.client(functions.messages.DeleteHistoryRequest(
                peer=userid,
                max_id=0,
                just_clear=True,
                revoke=False
            ))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'clear': res})

    async def get_me(self):
        try:
            res = await self.client.get_me()
            if (res == None):
                raise Exception
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'me': res})

    async def send_message(self, user, msg):
        try:
            res = await self.client.send_message(user, msg)
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'send': res})

    async def send_photo(self, user, msg, photo_path):
        try:
            res = await self.client.send_file(user, photo_path, caption=msg)
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'send': res})

    async def get_dialogs(self):
        try:
            res = await self.client.get_dialogs()
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'dialogs': res})

    async def get_chat_history(self, chat_id):
        try:
            res = await self.client(functions.messages.GetHistoryRequest(
                peer=chat_id,
                offset_id=0,
                offset_date=datetime.datetime.now(),
                add_offset=0,
                limit=100,
                max_id=0,
                min_id=0,
                hash=0
            ))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'history': res})

    async def get_chat_id(self, chatname):
        try:
            res = await self.client.get_peer_id(chatname)
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'chat_id': res})

    async def read_history_chat(self, chat_id):
        try:
            res = await self.client(functions.channels.ReadHistoryRequest(
                channel=chat_id,
                max_id=0
            ))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'read_history': res})

    async def increment_views(self, chat_id, id, increment):
        try:
            res = await self.client(functions.messages.GetMessagesViewsRequest(
                peer=chat_id,
                id=[id],
                increment=increment
            ))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'increment': res})

    async def change_photo(self, photo_path):
        try:
            res = await self.client(functions.photos.UploadProfilePhotoRequest(await self.client.upload_file(photo_path)))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True)

    async def set_firstname(self, firstname):
        try:
            res = await self.client(functions.account.UpdateProfileRequest(
                first_name=firstname
            ))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True)

    async def set_about(self, about):
        try:
            res = await self.client(functions.account.UpdateProfileRequest(
                about=about
            ))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True)

    async def get_entity(self, channel_link):
        try:
            channel = await self.client.get_entity(channel_link)
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'channel': channel})

    async def get_channel(self, channel_link):
        try:
            channel = await self.get_entity(channel_link)
            if (channel['status'] == False):
                return self.return_data(status=False, error_msg='get_channel')
            channel = channel['data']['channel']
            info = await self.client(functions.channels.GetFullChannelRequest(channel=channel))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'info': info})

    async def export_chat_invite_link(self, channel_link):
        try:
            channel = await self.get_entity(channel_link)
            if (channel['status'] == False):
                return self.return_data(status=False, error_msg='get_channel')
            channel = channel['data']['channel']
            info = self.client(functions.messages.ExportChatInviteRequest(peer=channel))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True, data={'info': info})

    async def update_username(self, channel_link, new_username):
        try:
            await self.client(functions.channels.UpdateUsernameRequest(channel=channel_link,
                                                                       username=new_username))
        except TimeoutError:
            return self.return_data(status=False, error_msg='TimeoutError')
        except Exception as e:
            return self.return_data(status=False, error_msg=str(e))

        return self.return_data(status=True)
